# JagPortfolio

This is my primary portflio. This is my only portfolio. I love my portfolio. I will work on it till i am satisfied that it does what it needs to do..